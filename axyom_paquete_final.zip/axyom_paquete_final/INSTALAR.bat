@echo off
chcp 65001 >nul
title AXYOM v7 — Instalador

echo.
echo  ╔══════════════════════════════════════════════╗
echo  ║   AXYOM Auditor v7.0 — Instalador           ║
echo  ║   Michel Antonio Duran Cornejo               ║
echo  ║   Chile 2026                                 ║
echo  ╚══════════════════════════════════════════════╝
echo.

:: ── 1. Verificar Rust ─────────────────────────────────────────
echo [1/5] Verificando Rust...
rustc --version >nul 2>&1
if %errorlevel% neq 0 (
    echo  Rust no encontrado. Instalando...
    winget install Rustlang.Rustup -e --silent
    if %errorlevel% neq 0 (
        echo  ERROR: No se pudo instalar Rust automaticamente.
        echo  Instala manualmente desde: https://rustup.rs
        pause
        exit /b 1
    )
    echo  Rust instalado. Recarga el PATH...
    call refreshenv >nul 2>&1
) else (
    for /f "tokens=*" %%i in ('rustc --version') do echo  OK: %%i
)

:: ── 2. Toolchain MSVC ─────────────────────────────────────────
echo.
echo [2/5] Configurando toolchain Windows (MSVC)...
rustup default stable-x86_64-pc-windows-msvc >nul 2>&1
rustup component add llvm-tools >nul 2>&1
echo  OK: toolchain listo

:: ── 3. Visual Studio Build Tools ──────────────────────────────
echo.
echo [3/5] Verificando Visual Studio Build Tools...
winget install Microsoft.VisualStudio.2022.BuildTools -e --silent >nul 2>&1
echo  OK: Build Tools verificados

:: ── 4. Compilar motor Rust ────────────────────────────────────
echo.
echo [4/5] Compilando motor AXYOM (5-10 minutos primera vez)...
echo  Por favor espera...
cargo build --release
if %errorlevel% neq 0 (
    echo.
    echo  ERROR: Fallo la compilacion.
    echo  Pega el error de arriba en el chat con Claude.
    pause
    exit /b 1
)

:: ── 5. Verificar resultado ────────────────────────────────────
echo.
echo [5/5] Verificando instalacion...
if exist "target\release\axyom.exe" (
    echo  OK: axyom.exe compilado correctamente
    for %%i in (target\release\axyom.exe) do echo  Tamanio: %%~zi bytes
) else (
    echo  ERROR: No se encontro axyom.exe
    pause
    exit /b 1
)

:: ── Demo ─────────────────────────────────────────────────────
echo.
echo ══════════════════════════════════════════════════
echo  INSTALACION COMPLETA
echo ══════════════════════════════════════════════════
echo.
echo  Corriendo demo con datos de ejemplo...
echo.
target\release\axyom.exe audit --fuente csv --conexion demo_trabajadores.csv --reglas mineria --export

echo.
echo ══════════════════════════════════════════════════
echo  Listo. Archivos generados en esta carpeta:
echo    reporte.pdf         — reporte legal
echo    reporte_evidencia.json — hash SHA3 verificable
echo ══════════════════════════════════════════════════
echo.
pause
