@echo off
title AXYOM v7 - Instalador completo

cd /d "%~dp0"

echo.
echo ============================================
echo  AXYOM Mineria v7.0 - Instalador completo
echo  Michel Antonio Duran Cornejo - Chile 2026
echo ============================================
echo.

:: ── PASO 1: Verificar Rust ────────────────────────────────────
echo [1/6] Verificando Rust...
rustc --version >nul 2>&1
if %errorlevel% neq 0 (
    echo Rust no encontrado. Descargando instalador...
    curl -o "%TEMP%\rustup-init.exe" https://static.rust-lang.org/rustup/dist/x86_64-pc-windows-msvc/rustup-init.exe
    if %errorlevel% neq 0 (
        echo ERROR: No se pudo descargar Rust.
        echo Instala manualmente desde: https://rustup.rs
        pause
        exit /b 1
    )
    "%TEMP%\rustup-init.exe" -y --default-toolchain stable-x86_64-pc-windows-gnu
    call "%USERPROFILE%\.cargo\env"
) else (
    echo OK: Rust encontrado
)

:: ── PASO 2: Instalar MSYS2 si no existe ───────────────────────
echo.
echo [2/6] Verificando MSYS2 y MinGW...
if exist "C:\msys64\mingw64\bin\dlltool.exe" (
    echo OK: dlltool.exe encontrado
    goto :path_ok
)
if exist "C:\msys64\usr\bin\dlltool.exe" (
    echo OK: dlltool.exe encontrado
    goto :path_ok
)

echo MinGW no encontrado. Instalando via winget...
winget install msys2.msys2 -e --silent
if %errorlevel% neq 0 (
    echo ADVERTENCIA: No se pudo instalar MSYS2 automaticamente.
    echo Descarga manualmente desde: https://www.msys2.org
    echo Luego ejecuta en MSYS2: pacman -S mingw-w64-x86_64-gcc
    pause
)

echo Instalando compilador C++ de MinGW...
if exist "C:\msys64\usr\bin\bash.exe" (
    C:\msys64\usr\bin\bash.exe -lc "pacman -S --noconfirm mingw-w64-x86_64-gcc"
)

:path_ok

:: ── PASO 3: Agregar MinGW al PATH ─────────────────────────────
echo.
echo [3/6] Configurando PATH para MinGW...
if exist "C:\msys64\mingw64\bin" (
    setx PATH "C:\msys64\mingw64\bin;%PATH%" >nul 2>&1
    set "PATH=C:\msys64\mingw64\bin;%PATH%"
    echo OK: C:\msys64\mingw64\bin agregado al PATH
) else (
    echo ADVERTENCIA: C:\msys64\mingw64\bin no encontrado
)

:: ── PASO 4: Configurar toolchain GNU ──────────────────────────
echo.
echo [4/6] Configurando Rust toolchain GNU (incluye dlltool)...
rustup toolchain install stable-x86_64-pc-windows-gnu >nul 2>&1
rustup default stable-x86_64-pc-windows-gnu >nul 2>&1
rustup component add llvm-tools --toolchain stable-x86_64-pc-windows-gnu >nul 2>&1
echo OK: toolchain GNU configurado

:: ── PASO 5: Compilar AXYOM ────────────────────────────────────
echo.
echo [5/6] Compilando motor AXYOM...
echo (primera vez: 5-10 minutos, paciencia...)
echo.

cargo build --release

if not exist "target\release\axyom.exe" (
    echo.
    echo ERROR: No compilo.
    echo Solucion: abre MSYS2 y ejecuta: pacman -S mingw-w64-x86_64-gcc
    echo Luego cierra y vuelve a ejecutar este bat.
    pause
    exit /b 1
)

:: ── PASO 6: Demo ──────────────────────────────────────────────
echo.
echo [6/6] Corriendo demo con datos de ejemplo...
echo.
target\release\axyom.exe audit --fuente csv --conexion demo_trabajadores.csv --reglas mineria --export

echo.
echo ============================================
echo INSTALACION COMPLETA
echo ============================================
echo.
echo Archivos generados:
echo   reporte.pdf            - reporte legal PDF
echo   reporte_evidencia.json - hash SHA3 verificable
echo.
echo Comandos disponibles:
echo   target\release\axyom.exe info
echo   target\release\axyom.exe audit --fuente csv --conexion TU_ARCHIVO.csv --reglas mineria --export
echo   target\release\axyom.exe verify reporte_evidencia.json HASH
echo   target\release\axyom.exe api --puerto 8080
echo.
echo ============================================
echo  AXYOM v7.0 - Chile 2026 - 0 = 0
echo ============================================
echo.
pause
